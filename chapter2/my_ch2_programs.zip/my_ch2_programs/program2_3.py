#program2_3
#by Michael Napoli COP1000

def main():

    #prompt the user to enter the price and quantity of items
    print('Time to check out: ')

    #entering the price and quantity
    itemPrice = float(input("Enter the item's price: "))
    itemQuantity = int(input('Enter the number of items: '))

    #doing the math to add up the items and calculate sales tax
    totalPrice = itemPrice* itemQuantity
    salesTax = totalPrice* (.07)
    totalPlusTax = totalPrice + salesTax

    #print the output
    print(f'The subtotal is ${totalPrice: ,.2f}.')
    print(f'The sales tax is ${salesTax: ,.2f}.')
    print(f'Your total is ${totalPlusTax: ,.2f}.')

main()
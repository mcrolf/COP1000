#program3_1 COP1000
#by Michael Napoli 2275778

def main():
    
    #defined variables for calculations
    overtimeMultiplyer= 1.5
    regularHours= 40
    regularPay= float()

    
    #defining variables for user input (hourly rate and hours worked)
    hourlyRate= float(input('What is the hourly rate? '))
    hoursWorked= float(input('How many hours were worked? '))

    #payout calculations for regular pay
    if hoursWorked <= regularHours:
        normalHours= hoursWorked
        overtimeHours= 0
    #calculations for overtime pay
    else:
        normalHours= regularHours
        overtimeHours= hoursWorked - regularHours
    overtimePay= overtimeHours * hourlyRate * overtimeMultiplyer
    regularPay= regularHours * hourlyRate
    
    #calculation for total pay
    grossPay= overtimePay + regularPay   
    
    #the output text with the results from the calculations
    print(f'Regular Pay= ${regularPay:,.2f}')
    print(f'Overtime Pay= ${overtimePay:,.2f}')
    print(f'Gross Pay= ${grossPay:,.2f}')

main()
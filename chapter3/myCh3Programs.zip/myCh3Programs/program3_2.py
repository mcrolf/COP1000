#program3_2   COP1000
#by Michael Napoli   2275778

def main():

    #user input and defining the number the user enters
    yourNumber= int(input('Enter an odd multiple of 19 that is more than 60 and less than 200: '))

    #determining correct input values
    correctNumber1= 95
    correctNumber2= 133
    correctNumber3= 171
    
    #output for correct numerical input
    
    #correct for 19 x 5
    if yourNumber == correctNumber1:
        print('Good Job! The multiple is 5')
    #correct for 19 x 7
    elif yourNumber == correctNumber2:
        print('Good Job! The multiple is 7')
    #corect for 19 x 9
    elif yourNumber == correctNumber3:
        print('Good Job! The multiple is 9')
    #when the input is not one of the correct odd multiples of 19 between 60 and 200
    else:
        print('Incorrect Input')

main()
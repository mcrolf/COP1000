# if_else.py

def main():

    num = int(input('Enter an integer less than 10 '))
    if num < 10:
        print(f'{num} was good input')
        
    else:
        print(f'Sorry, {num} is not less than 10')

main() # run the main function
    

    
